"""Unit tests for the task scheduler."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from task_scheduler import TaskScheduler


class TaskSchedulerTests(unittest.TestCase):
    def test_extracts_highest_priority_first(self):
        scheduler = TaskScheduler()
        scheduler.insert("Email", 2)
        scheduler.insert("System update", 9)
        scheduler.insert("Backup", 5)
        self.assertEqual(scheduler.extract_max().name, "System update")
        self.assertEqual(scheduler.extract_max().name, "Backup")
        self.assertEqual(scheduler.extract_max().name, "Email")

    def test_empty_extract_returns_none(self):
        self.assertIsNone(TaskScheduler().extract_max())

    def test_peek_does_not_remove(self):
        scheduler = TaskScheduler()
        scheduler.insert("Compile", 4)
        self.assertEqual(scheduler.peek_max().name, "Compile")
        self.assertEqual(len(scheduler), 1)

    def test_equal_priorities_are_fifo(self):
        scheduler = TaskScheduler()
        scheduler.insert("First", 3)
        scheduler.insert("Second", 3)
        self.assertEqual(scheduler.extract_max().name, "First")
        self.assertEqual(scheduler.extract_max().name, "Second")

    def test_rejects_empty_name(self):
        with self.assertRaises(ValueError):
            TaskScheduler().insert("  ", 1)

    def test_rejects_non_integer_priority(self):
        with self.assertRaises(ValueError):
            TaskScheduler().insert("Bad priority", "high")

    def test_length_and_pending_order(self):
        scheduler = TaskScheduler()
        scheduler.insert("Low", 1)
        scheduler.insert("High", 10)
        self.assertEqual(len(scheduler), 2)
        self.assertEqual([t.name for t in scheduler.pending_tasks()], ["High", "Low"])
        self.assertEqual(len(scheduler), 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
