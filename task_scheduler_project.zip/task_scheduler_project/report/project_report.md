# Task Scheduler Using a Max-Heap

## 1. Project Title
**Task Scheduler Using a Max-Heap**

## 2. Objective
The objective is to simulate a simple operating-system task scheduler that always selects the pending task with the highest priority. The required operations are `INSERT` and `EXTRACT-MAX`.

## 3. Methodology
A binary heap is used to maintain the priority order. Python's built-in `heapq` module implements a min-heap, so each priority is stored as a negative value to provide max-heap behavior. A monotonically increasing task ID makes tasks with equal priorities execute in insertion order. The program also provides `PEEK` and `LIST` commands to make the simulation easier to demonstrate.

## 4. Implementation
The implementation is in `src/task_scheduler.py`.
- `insert(name, priority)` validates the inputs and inserts a task.
- `extract_max()` removes and returns the highest-priority task; it returns `None` when empty.
- `peek_max()` reads the highest-priority task without removing it.
- `pending_tasks()` returns a sorted view without changing the heap.
- The command-line interface accepts commands from the user.

A higher integer priority means greater urgency. Task names must be non-empty, and priorities must be integers.

## 5. Experiments and Results
The benchmark script was run in the current Python environment. For each input size, five runs were measured using `time.perf_counter()`. Random priorities were generated with fixed seeds to make the experiment reproducible. The reported insertion value is the mean time to insert all tasks. The extraction value is the mean time to remove all tasks. Times depend on the computer and Python runtime, so they should be treated as measurements of this environment, not universal performance guarantees.

| Number of tasks | Mean insert-all time (ms) | Mean extract-all time (ms) |
|---:|---:|---:|
| 1000 | 4.321 | 1.123 |
| 5000 | 42.709 | 7.469 |
| 10000 | 14.004 | 15.018 |
| 20000 | 135.053 | 109.474 |
| 40000 | 118.967 | 122.445 |

Charts are provided in `charts/insertion_time.png` and `charts/extraction_time.png`. The raw measurements, including standard deviations, are saved in `results/benchmark_results.csv`.

## 6. Complexity Analysis
For a binary heap containing *n* tasks:
- `INSERT`: **O(log n)** worst-case time, because the new item may move up the heap.
- `EXTRACT-MAX`: **O(log n)** worst-case time, because the last item replaces the root and may move down.
- `PEEK`: **O(1)** time.
- Storage: **O(n)** for *n* pending tasks.
- Listing all tasks in priority order in this implementation sorts a snapshot, requiring **O(n log n)** time and **O(n)** additional space.

## 7. Testing
Automated unit tests cover priority order, extraction from an empty queue, non-destructive peek, FIFO behavior for equal priorities, input validation, and listing/length behavior. The test run log is included at `results/test_results.txt`.

## 8. Conclusion
The project demonstrates how a max-heap can support a priority-based task scheduler. The highest-priority task is extracted first, while insertion and extraction remain logarithmic-time operations. The command-line interface makes the operations easy to test manually, and the included tests and benchmark provide evidence for the implementation's behavior.

## 9. References
1. Python Software Foundation, *heapq — Heap queue algorithm*: https://docs.python.org/3/library/heapq.html
2. Python Software Foundation, *unittest — Unit testing framework*: https://docs.python.org/3/library/unittest.html
