"""Reproduce timing experiments and plots for the max-heap scheduler."""
import csv
import random
import statistics
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
from task_scheduler import TaskScheduler

SIZES = [1000, 5000, 10000, 20000, 40000]
REPEATS = 5
RNG_SEED = 20261029


def timed_run(n, seed):
    rng = random.Random(seed)
    tasks = [(f"Task {i}", rng.randint(1, 1000)) for i in range(n)]
    scheduler = TaskScheduler()
    t0 = time.perf_counter()
    for name, priority in tasks:
        scheduler.insert(name, priority)
    insert_seconds = time.perf_counter() - t0
    t0 = time.perf_counter()
    while scheduler.extract_max() is not None:
        pass
    extract_seconds = time.perf_counter() - t0
    return insert_seconds, extract_seconds


def main():
    out = ROOT / "results" / "benchmark_results.csv"
    rows = []
    for n in SIZES:
        insert_times, extract_times = [], []
        for repeat in range(REPEATS):
            ins, ext = timed_run(n, RNG_SEED + n + repeat)
            insert_times.append(ins)
            extract_times.append(ext)
        rows.append({
            "task_count": n,
            "repeats": REPEATS,
            "insert_mean_seconds": statistics.mean(insert_times),
            "insert_stdev_seconds": statistics.stdev(insert_times),
            "extract_all_mean_seconds": statistics.mean(extract_times),
            "extract_all_stdev_seconds": statistics.stdev(extract_times),
        })
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("Benchmark CSV saved. Install matplotlib to regenerate charts.")
        return

    charts = ROOT / "charts"
    charts.mkdir(exist_ok=True)
    xs = [r["task_count"] for r in rows]
    insert_ms = [r["insert_mean_seconds"] * 1000 for r in rows]
    extract_ms = [r["extract_all_mean_seconds"] * 1000 for r in rows]

    plt.figure()
    plt.plot(xs, insert_ms, marker="o")
    plt.xlabel("Number of tasks inserted")
    plt.ylabel("Mean elapsed time (ms)")
    plt.title("Max-Heap: Insertion Time")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(charts / "insertion_time.png", dpi=160)
    plt.close()

    plt.figure()
    plt.plot(xs, extract_ms, marker="o")
    plt.xlabel("Number of tasks extracted")
    plt.ylabel("Mean elapsed time (ms)")
    plt.title("Max-Heap: Extract All Tasks")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(charts / "extraction_time.png", dpi=160)
    plt.close()
    print(f"Saved measurements to {out}")
    print(f"Saved charts to {charts}")


if __name__ == "__main__":
    main()
