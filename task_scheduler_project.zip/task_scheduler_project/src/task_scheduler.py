"""Priority-based task scheduler implemented with a max-heap."""

from dataclasses import dataclass, field
from typing import List, Optional
import heapq
import itertools


@dataclass(order=False)
class Task:
    """A scheduled task. Larger priority values mean higher priority."""
    name: str
    priority: int
    task_id: int = 0

    def __str__(self) -> str:
        return f"{self.name} (priority={self.priority}, id={self.task_id})"


class TaskScheduler:
    """Max-heap scheduler supporting INSERT and EXTRACT-MAX.

    Python's heapq is a min-heap, so priorities are stored as negative values.
    A sequence number provides deterministic ordering for equal priorities.
    """

    def __init__(self) -> None:
        self._heap = []
        self._counter = itertools.count(1)

    def insert(self, name: str, priority: int) -> Task:
        """Insert a task and return it. Higher numeric priority runs first."""
        if not isinstance(name, str) or not name.strip():
            raise ValueError("Task name must be a non-empty string.")
        if isinstance(priority, bool) or not isinstance(priority, int):
            raise ValueError("Priority must be an integer.")
        task = Task(name=name.strip(), priority=priority, task_id=next(self._counter))
        heapq.heappush(self._heap, (-task.priority, task.task_id, task))
        return task

    def extract_max(self) -> Optional[Task]:
        """Remove and return the highest-priority task, or None if empty."""
        if not self._heap:
            return None
        return heapq.heappop(self._heap)[2]

    def peek_max(self) -> Optional[Task]:
        """Return the highest-priority task without removing it."""
        return self._heap[0][2] if self._heap else None

    def is_empty(self) -> bool:
        return not self._heap

    def __len__(self) -> int:
        return len(self._heap)

    def pending_tasks(self) -> List[Task]:
        """Return a sorted snapshot of pending tasks without changing the heap."""
        return [entry[2] for entry in sorted(self._heap)]


def run_cli() -> None:
    """Run a small interactive command-line demonstration."""
    scheduler = TaskScheduler()
    print("=== Task Scheduler (Max-Heap) ===")
    print("Commands: INSERT <priority> <task name> | EXTRACT-MAX | PEEK | LIST | EXIT")
    while True:
        try:
            raw = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting.")
            break
        if not raw:
            continue
        parts = raw.split()
        command = parts[0].upper()
        if command == "EXIT":
            print("Goodbye.")
            break
        elif command == "INSERT":
            if len(parts) < 3:
                print("Usage: INSERT <integer priority> <task name>")
                continue
            try:
                priority = int(parts[1])
                name = " ".join(parts[2:])
                task = scheduler.insert(name, priority)
                print(f"Inserted: {task}")
            except ValueError as exc:
                print(f"Error: {exc}")
        elif command == "EXTRACT-MAX":
            task = scheduler.extract_max()
            print(f"Next task: {task}" if task else "Scheduler is empty.")
        elif command == "PEEK":
            task = scheduler.peek_max()
            print(f"Highest priority: {task}" if task else "Scheduler is empty.")
        elif command == "LIST":
            tasks = scheduler.pending_tasks()
            if not tasks:
                print("No pending tasks.")
            else:
                print("Pending tasks (highest priority first):")
                for task in tasks:
                    print(f"  - {task}")
        else:
            print("Unknown command. Use INSERT, EXTRACT-MAX, PEEK, LIST, or EXIT.")


if __name__ == "__main__":
    run_cli()
